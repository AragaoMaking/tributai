# TributAI — prompts por fase (VS Code)

**Antes de começar**
1. Crie a pasta `tributai` e abra no VS Code (Arquivo > Abrir Pasta).
2. Coloque nela: `tributai.html`, `db/001_schema.sql`, os 3 repositórios da Receita descompactados e o arquivo `.github/copilot-instructions.md` deste pacote (mantenha o caminho exato).
3. Abra o chat da IA, escolha o **modo Agente** e cole **um prompt por vez**, na ordem. Só passe para o próximo quando eu confirmar que a fase anterior ficou boa.

---

## Fase 0 — Conhecer o terreno
Siga as instruções do projeto. Não escreva código de aplicação ainda. 1) Verifique se tenho Node, Java 25, Docker e Git e me diga o que instalar. 2) Leia README, docs, licença e dependências dos 3 repositórios da Receita e do `db/001_schema.sql`. 3) Me entregue um relatório curto: como cada motor roda, entradas e saídas, o que cada um calcula e o que NÃO calcula, e riscos. Não invente nada que não esteja no código.

## Fase 1 — Estrutura visual e navegação
Crie `apps/web` com Next.js, TypeScript e Tailwind. Implemente o layout (menu lateral responsivo, barra superior, tema claro e escuro) e as 11 páginas do menu: Visão geral, Clientes, Simulador tributário, Comparador de regimes, Reforma Tributária, Relatórios, Alertas tributários, Assistente IA, Equipe, Assinatura, Configurações. Use o `tributai.html` como referência visual. Páginas ainda sem função devem dizer claramente “Planejado: fase X”.

## Fase 2 — Autenticação e banco
Transforme `db/001_schema.sql` em migrações, suba o Postgres local e corrija o que falhar. Implemente cadastro, login, logout, recuperação de senha, papéis e proteção de rotas. Escreva testes que provem que um escritório não enxerga dados de outro e que o empresário só vê o que foi compartilhado.

## Fase 3 — Clientes
Cadastro de empresas em 5 etapas (identificação, fiscal, financeiro, contato, configurações) com validação e máscara de CNPJ, rascunho, edição, arquivamento, exclusão com confirmação, busca, filtros, ordenação, paginação e importação por planilha. Página de cada empresa com 8 abas. Tudo salvo no banco, com feedback em toda ação.

## Fase 4 — Dashboard
Faça a Visão geral ler tudo do banco: totais, regimes, empresas com pendências, atividades recentes e ações rápidas. Onde ainda não houver cálculo oficial, mostre “pendente”.

## Fase 5 — Simulador (motor regime regular)
Empacote o motor do regime regular em Docker (rede interna), gere o banco SQLite necessário e crie a interface `MotorTributario` no backend. Monte a operação a partir do cadastro, chame o motor, salve a simulação sem sobrescrever as antigas (com versão do motor) e mostre o resultado com memória de cálculo e a seção “O que muda para esta empresa?”. ICMS, ISS, PIS, COFINS e IPI ficam como `pendente`. Crie testes de consistência com os exemplos de `docs/exemplos.md` do repositório.

## Fase 6 — Histórico e comparador
Histórico de simulações com comparação entre elas. Comparador de regimes (Simples, Presumido e Real) lado a lado, sem afirmar que um é melhor quando faltarem dados.

## Fase 7 — Relatórios em PDF
Gerador de PDF com logo do escritório, empresa, CNPJ, período, resumo, tributos, comparação, memória de cálculo, fundamentação legal, premissas e ressalvas. Visualizar antes, baixar e compartilhar com o cliente mediante autorização.

## Fase 8 — Portal do empresário
Área própria do cliente: relatórios e simulações compartilhados, notificações, envio de documentos e mensagens ao contador. Teste que ele não acessa dados internos do escritório nem de outras empresas.

## Fase 9 — Simples Nacional, DANFSE e Assistente IA
Integre o motor do Simples Nacional e o gerador de DANFSE pela mesma interface de motores. Crie o Assistente IA que explica simulações e legislação usando só fontes oficiais, cita a referência e diz quando houver incerteza. Sem enviar dados sensíveis a serviços de IA sem controle.

## Fase 10 — Assinaturas e testes finais
Planos Starter (até 10 clientes), Profissional (até 100) e Escritório (configurável), com limites, período de teste, vencimento e cancelamento, usando a interface de gateway com implementação falsa. Depois, teste os 15 fluxos principais (criar conta, cadastrar escritório e empresa, simular, comparar, gerar e compartilhar relatório, portal do empresário, permissões, isolamento de dados, erros e estados de carregamento) e me entregue um relatório do que passou e do que falhou.
