# TributAI — instruções permanentes

TributAI é um SaaS de gestão tributária e simulação da Reforma Tributária para escritórios de contabilidade, contadores autônomos e empresas. Slogan: “Inteligência tributária. Decisões mais inteligentes.”

## Como trabalhar comigo
- Sou iniciante. Explique em português simples, em passos pequenos. Antes de rodar comandos que instalam, apagam ou sobrescrevem algo, diga o que fazem e espere meu OK.
- Trabalhe uma fase por vez. Ao fim: rode os testes, faça commit e resuma o que funciona, o que está pendente e o que preciso decidir.
- Se faltar informação (chave, conta, regra tributária), diga exatamente o que falta e continue com o resto.

## Regras inegociáveis
1. Nunca invente alíquota, lei, artigo, endpoint ou resultado. Nunca apresente estimativa como cálculo oficial.
2. Todo valor de imposto tem origem: `motor_rfb`, `regra_documentada` (com fundamento legal e revisão) ou `pendente`. Sem motor conectado, mostre “pendente”, nunca um número.
3. Simulações guardam entrada, versão do motor, regras, premissas e resultado, e nunca são sobrescritas.
4. Cada escritório só acessa os próprios dados (RLS no banco). O empresário só vê o que o contador compartilhou. Sem segredos no código: use variáveis de ambiente. Arquivos fiscais só em armazenamento privado.
5. Todo botão faz algo e todo formulário salva. Toda ação dá feedback (sucesso, erro, atenção, carregando, vazio). Dados de demonstração sempre marcados como fictícios.

## Stack
Next.js + TypeScript, Tailwind CSS, PostgreSQL com RLS (Supabase local via Docker ou Postgres em Docker), armazenamento privado de arquivos. Visual: azul-marinho, branco/cinza, verde (positivo), vermelho (alerta), tema claro e escuro, responsivo. Interface em português do Brasil.

## Já existe
`tributai.html` (protótipo de comportamento e visual), `db/001_schema.sql` (esquema PostgreSQL nunca testado: validar e virar migrações) e os 3 repositórios MIT da Receita Federal.

## Motores da Receita (confirme lendo o código antes de integrar)
- Regime regular (Java 25, Spring Boot): `http://localhost:8080/api`. `POST /calculadora/regime-geral`, `POST /calculadora/observabilidade/regime-geral`, `POST /calculadora/base-calculo/base-calculo-unificada`, `/xml/generate`, `/xml/validate` e `GET /dados-abertos/...` (CST, cClassTrib, NCM, NBS, `aliquota-uniao`, `aliquota-uf`, `aliquota-municipio`). Exige gerar o banco SQLite com `./mvnw flyway:migrate -Dflyway.configFiles=./flyway/flyway-pro.conf` e rodar com o perfil `offline`. Calcula só CBS, IBS e Imposto Seletivo, item a item. Não calcula ICMS, ISS, PIS, COFINS, IPI nem faz apuração do período.
- Simples Nacional (Java): `http://localhost:8082/api`, `POST /calculadora/observabilidade/simples-nacional`.
- Gerador de DANFSE (Go 1.27+, Docker): porta 8080 por padrão; use `SERVER_PORT=8081`.
- Payload do regime geral: `dhFatoGerador`, `municipio` (IBGE), `uf`, `itens` com `ncm` ou `nbs`, `cst`, `cClassTrib`, `baseCalculo`, `aliquotasNominais` (`cbs`, `ibsEstadual`, `ibsMunicipal`). Exemplo em `docs/exemplos.md` do repositório.

## Arquitetura
Monorepo: `apps/web`, `services/` (cada motor da Receita em Docker, só na rede interna, nunca exposto ao navegador), `db/migrations`, `docs/`. Uma interface `MotorTributario` no backend esconde os motores, para trocar versões sem reescrever a plataforma. Registre a versão usada e crie testes de consistência com os exemplos dos repositórios. Gateway de pagamento: só a interface, com implementação falsa claramente marcada.
